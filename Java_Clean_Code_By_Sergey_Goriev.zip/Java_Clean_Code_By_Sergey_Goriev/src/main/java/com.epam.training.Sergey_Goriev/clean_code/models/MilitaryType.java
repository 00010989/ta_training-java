package com.epam.training.Sergey_Goriev.clean_code.models;

public enum MilitaryType {
    FIGHTER, BOMBER, TRANSPORT
}
