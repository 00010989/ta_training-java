package com.epam.training.Sergey_Goriev.clean_code.planes;

import com.epam.training.Sergey_Goriev.Plane;
import com.epam.training.Sergey_Goriev.clean_code.models.ClassificationLevel;
import com.epam.training.Sergey_Goriev.clean_code.models.ExperimentalType;

public class ExperimentalPlane extends Plane {
    private final ClassificationLevel classificationLevel;
    private final ExperimentalType experimentalType;

    public ExperimentalPlane(String model, int speed, int distance, int capacity, ExperimentalType type, ClassificationLevel level) {
        super(model, speed, distance, capacity);
        this.experimentalType = type;
        this.classificationLevel = level;
    }

    public ExperimentalType getExperimentalType() {
        return experimentalType;
    }

    public ClassificationLevel getClassificationLevel(){
        return classificationLevel;
    }

    @Override
    public int hashCode() {
        return super.hashCode();
    }


    @Override
    public boolean equals(Object experimentalPlane) {
        if (this == experimentalPlane) return true;
        if (!(experimentalPlane instanceof ExperimentalPlane)) return false;
        return super.equals(experimentalPlane);
    }

    @Override
    public String toString() {
        return "experimentalPlane{" +
                "model='" + getPlaneModel() + '\'' +
                '}';
    }
}