package com.epam.training.Sergey_Goriev.Electronic_Watch;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.Scanner;

public class ElectronicWatch {
    public static void main(String[] args) {
        int UserInputtedValue = new Scanner(System.in).nextInt();
        int Hours = (UserInputtedValue / 60 / 60);
        int Minutes = UserInputtedValue / 60 % 60;
        int Seconds = UserInputtedValue % 60;
        String strHour =  (Hours == 24) ? "0" : Integer.toString(Hours);
        System.out.println(strHour + ":" + str(Minutes) + ":" + str(Seconds));
    }

    private static String str(int n) {
        return n < 10 ? "0" + n : "" + n;
    }
}
