package com.epam.training.Sergey_Goriev.Beware_of_Dogs.residents.dogs;

public class Puppy extends Dog {
    public Puppy(String name) { super(name); }
    @Override
    public String toString() { return "Puppy " + name; }
}
