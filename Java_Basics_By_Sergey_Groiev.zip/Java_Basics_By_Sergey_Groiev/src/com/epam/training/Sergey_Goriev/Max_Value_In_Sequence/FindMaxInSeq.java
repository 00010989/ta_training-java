package com.epam.training.Sergey_Goriev.Max_Value_In_Sequence;

import java.util.Scanner;

public class FindMaxInSeq {
    public static int max() {
        Scanner scanner = new Scanner(System.in);
        int InputedSequence = scanner.nextInt();
        int MaxValue = InputedSequence;
        while (true) {
            InputedSequence = scanner.nextInt();
            if(InputedSequence==0)break;
            if (InputedSequence >= MaxValue ) {
                MaxValue = InputedSequence;
            }
        }
        return MaxValue;
    }

    public static void main (String[]args){
        System.out.println("Please enter your desired sequence of integers: ");
        FindMaxInSeq test = new FindMaxInSeq();
        System.out.println("Your max value is: " + max());
    }
}

