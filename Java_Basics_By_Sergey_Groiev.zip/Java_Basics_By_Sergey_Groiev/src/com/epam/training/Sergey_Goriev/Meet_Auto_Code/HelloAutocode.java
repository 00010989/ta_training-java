package com.epam.training.Sergey_Goriev.Meet_Auto_Code;

public class HelloAutocode {
    public static void main(String[] args) {
        System.out.println("Hello, Autocode!");
    }
}
