package com.epam.training.Sergey_Goriev.Decrementing_Carousel;

import java.util.Arrays;
import java.util.*;

public class CarouselRun {
    public static void main(String[] args) {
        CarouselRun run = new DecrementingCarousel(7).run();
        System.out.println(run.isFinished()); //true
        System.out.println(run.next()); //-1
        System.out.println(" ");

        DecrementingCarousel carousel = new DecrementingCarousel(7);
        carousel.addElement(2);
        carousel.addElement(3);
        carousel.addElement(1);
        run = carousel.run();

        System.out.println(run.isFinished()); //false

        System.out.println(run.next()); //2
        System.out.println(run.next()); //3
        System.out.println(run.next()); //1

        System.out.println(run.next()); //1
        System.out.println(run.next()); //2

        System.out.println(run.next()); //1

        System.out.println(run.isFinished()); //true
        System.out.println(run.next()); //-1
        System.out.println(" "); //-1

        carousel = new DecrementingCarousel(3);

        System.out.println(carousel.addElement(-2)); //false
        System.out.println(carousel.addElement(0)); //false

        System.out.println(carousel.addElement(2)); //true
        System.out.println(carousel.addElement(3)); //true
        System.out.println(carousel.addElement(1)); //true

        //carousel is full
        System.out.println(carousel.addElement(2)); //false

        run = carousel.run();

        System.out.println(run.next()); //2
        System.out.println(run.next()); //3
        System.out.println(run.next()); //1

        System.out.println(run.next()); //1
        System.out.println(run.next()); //2

        System.out.println(run.next()); //1

        System.out.println(run.isFinished()); //true
        System.out.println(run.next()); //-1
        System.out.println(" ");

        carousel = new DecrementingCarousel(10);
        System.out.println(carousel.addElement(2)); //true
        System.out.println(carousel.addElement(3)); //true
        System.out.println(carousel.addElement(1)); //true

        carousel.run();

        System.out.println(carousel.addElement(2)); //false
        System.out.println(carousel.addElement(3)); //false
        System.out.println(carousel.addElement(1)); //false
        System.out.println(" ");

        carousel = new DecrementingCarousel(10);
        System.out.println(carousel.run() == null); //false
        System.out.println(carousel.run() == null); //true
    }

    int capacity;
    int sum;
    public int count;
    public static int [] decrementingCarousel;

    public CarouselRun() {
        capacity = DecrementingCarousel.capacity;
        count=0;
        for (int i=0; i<capacity; i++){
            if (DecrementingCarousel.decrementingCarousel[i]!=0) {
                count++;
            }
        }

        decrementingCarousel=new int[count];
        System.arraycopy(DecrementingCarousel.decrementingCarousel, 0, decrementingCarousel, 0, count);
        capacity=count;
        count=0;
    }

    public int next() {
        int summa=0;
        for (int a:decrementingCarousel){
            summa+=a;}
        if (summa==0) return (-1);
        else{
            if (decrementingCarousel[count]==0){
                if (count!=(capacity-1)) {count++;}
                else count =0;  }

            int carouselDouble2 =decrementingCarousel[count];
            decrementingCarousel[count]=decrementingCarousel[count]-1;

            if (count!=(capacity-1)) {count++;}
            else count =0;

            if (decrementingCarousel[count]==0){
                summa=0;
                for (int a:decrementingCarousel){
                    summa+=a;}
                if (summa!=0){
                    while (decrementingCarousel[count]==0 ) {
                        if (count!=(capacity-1)) {count++;}
                        else count =0;
                    }
                }
            }
            return carouselDouble2;
        }
    }

    public boolean isFinished() {
        int summa=0;
        for (int a:decrementingCarousel){
            summa+=a;}
        return summa == 0;
    }
}

