package com.epam.training.Sergey_Goriev.Gradually_Decreasing_Carousel;

import java.util.Arrays;

public class DecrementingCarousel {
    private int capacity;
    private int[] carousel;
    private int headAdd = 0;
    private boolean carouselRunning = false;

    public DecrementingCarousel(int capacity) {
        this.capacity = capacity;
        carousel = new int[capacity];
        Arrays.fill(carousel, 0);
    }

    public boolean addElement(int element) {
        if (element > 0 && headAdd < capacity && !carouselRunning) {
            carousel[headAdd] = element;
            headAdd++;
            return true;
        }
        return false;
    }

    public CarouselRun run() {
        if (!carouselRunning) {
            carouselRunning = true;
            return new CarouselRun(carousel, 0);
        }
        return null;
    }

    public int[] getCarousel() {
        return carousel;
    }

    public boolean thisCarouselRunning() {
        return carouselRunning;
    }

    public void setCarouselRunning(boolean carouselRunning) {
        this.carouselRunning = carouselRunning;
    }
}

