package com.epam.training.Sergey_Goriev.Figures_Extra_Challenge;

class Point {
    public static void main(String[] args) {
        double area = new Triangle(new Point(0,0), new Point(3, 0), new Point(0, 4)).area();
        int areaInt = (int) area;
        System.out.println(areaInt);
        System.out.println(" ");

        area = new Quadrilateral(new Point(1, 0), new Point(2, 1), new Point(1, 2), new Point(0, 1)).area();
        int areaInt2 = (int) area;
        System.out.println(areaInt2);
        System.out.println(" ");

        area = new Circle(new Point(1,1), 3).area();
        System.out.println(area);
        System.out.println(" ");

        Circle circle = new Circle(new Point(2,4), 5);
        System.out.println(circle.pointsToString().trim());
        System.out.println(circle.toString().trim());
        System.out.println(circle.leftmostPoint());
        System.out.println(" ");

        Point a = new Point(3, 4);
        Point b = new Point(2, 5);
        Point c = new Point(9, 4);
        Point d = new Point(6, 2);
        Quadrilateral quadrilateral = new Quadrilateral(a, b, c, d);
        System.out.println(quadrilateral.pointsToString());
        System.out.println(quadrilateral.toString());
        System.out.println(quadrilateral.leftmostPoint());
        System.out.println(" ");

        a = new Point(3, 4);
        b = new Point(2, 5);
        c = new Point(8, 4);
        Triangle triangle = new Triangle(a, b, c);
        System.out.println(triangle.pointsToString());
        System.out.println(triangle.toString());
        System.out.println(triangle.leftmostPoint());

    }

    public double x;
    public double y;

    @Override
    public String toString() {
        return "(" + x + "," + y + ")";
    }

    public Point(final double x, final double y) {
        this.x = x;
        this.y = y;
    }

    public double getX() {
        return x;
    }
    public double getY() {
        return y;
    }

    public boolean isTheSame(Point point) {
        return Figure.isRelativelyEqual(x, point.x) && Figure.isRelativelyEqual(y, point.y);
    }
}