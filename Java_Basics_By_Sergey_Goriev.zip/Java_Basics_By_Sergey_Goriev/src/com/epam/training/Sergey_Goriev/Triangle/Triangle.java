package com.epam.training.Sergey_Goriev.Triangle;

public class Triangle {
    private Point a, b, c;

    public Triangle(Point a, Point b, Point c) {
        if (a == null || b == null || c == null) {
            throw new IllegalArgumentException();
        }
        if (!isValidTriangle(a, b, c)) {
            throw new IllegalArgumentException("Points do not form a valid triangle");
        }
        this.a = a;
        this.b = b;
        this.c = c;
    }

    private boolean isValidTriangle(Point a, Point b, Point c) {
        double ab = a.distance(b);
        double bc = b.distance(c);
        double ca = c.distance(a);
        return ab + bc > ca && bc + ca > ab && ca + ab > bc;
    }

    public double area() {
        double ab = a.distance(b);
        double bc = b.distance(c);
        double ca = c.distance(a);
        double s = (ab + bc + ca) / 2;
        return Math.sqrt(s * (s - ab) * (s - bc) * (s - ca));
    }

    public Point centroid() {
        double x = (a.getX() + b.getX() + c.getX()) / 3;
        double y = (a.getY() + b.getY() + c.getY()) / 3;
        return new Point(x, y);
    }

    public static void main(String[] args) {
        Point a = new Point(0, 0);
        Point b = new Point(3, 0);
        Point c = new Point(0, 4);

        Triangle triangle = null;
        try {
            triangle = new Triangle(a, b, c);
        } catch (IllegalArgumentException e) {
            System.out.println("Result: exception, because such a triangle will be degenerated");
            return;
        }
        System.out.println("Area: " + (int)triangle.area());
        Point centroid = triangle.centroid();
        System.out.println("Centroid X: " + (int)centroid.getX());
        System.out.println("Centroid Y: " + (int)centroid.getY());
    }
}
