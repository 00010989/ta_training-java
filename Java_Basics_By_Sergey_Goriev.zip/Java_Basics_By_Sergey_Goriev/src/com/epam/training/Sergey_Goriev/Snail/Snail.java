package com.epam.training.Sergey_Goriev.Snail;

import java.util.Scanner;

public class Snail {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int a = scanner.nextInt();
        int b = scanner.nextInt();
        int h = scanner.nextInt();
        if (a >= h) {
            System.out.println(1);
        } else if (a <= b) {
            System.out.println("Impossible");
        } else {
            int round = 0;
            int passed = 0;
            while (passed < h) {
                round++;
                passed = passed + a;
                if (passed >= h) {
                    break;
                } else {
                    passed = passed - b;
                }
            }
            System.out.println(round);
        }
    }
}
