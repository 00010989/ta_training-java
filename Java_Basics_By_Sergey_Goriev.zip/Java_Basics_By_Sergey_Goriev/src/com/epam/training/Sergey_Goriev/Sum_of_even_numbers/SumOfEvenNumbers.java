package com.epam.training.Sergey_Goriev.Sum_of_even_numbers;

public class SumOfEvenNumbers {
    public static void main(String[] args) {
        int[] array = {-2,10,0,5};
        System.out.println(sum(array));
    };

        public static int sum(int[] array) {
            if (array == null || array.length == 0) {
                return 0;
            }
            int sum = 0;
            for (int j : array) {
                if (j % 2 == 0) {
                    sum += j;
                }
            }
            return sum;
        }
}
