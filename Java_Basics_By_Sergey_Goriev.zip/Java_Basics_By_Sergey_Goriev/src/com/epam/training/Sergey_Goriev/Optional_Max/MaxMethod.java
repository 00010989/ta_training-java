package com.epam.training.Sergey_Goriev.Optional_Max;

import java.util.OptionalInt;
import java.util.Arrays;

public class MaxMethod {
    public static OptionalInt max(int[] values) {
        if (values == null || values.length == 0) {
            return OptionalInt.empty();
        } else {
            return OptionalInt.of(Arrays.stream(values).max().getAsInt());
        }
    }

    public static void main(String[] args) {
        int[] vals = new int[]{-2, 0, 10, 5};
        OptionalInt result = MaxMethod.max(vals);
        System.out.println(result.getAsInt() == 10); // true
    }
}

