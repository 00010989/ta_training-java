package com.epam.training.Sergey_Goriev.Figures;

import static java.lang.Math.sqrt;

class Circle extends Figure {
    Point centr;
    double radius;

    public Circle(Point centr, double radius) throws IllegalArgumentException {
        if (centr != null) {
            this.centr = centr;
            this.radius = radius;
        }
        if (radius <= 0 || centr == null) {
            throw new IllegalArgumentException();
        }
    }

    @Override
    public Point centroid() {
        return centr;
    }

    @Override
    public double area() {
        return (double) (Math.PI * Math.pow(radius, 2));
    }

    public String pointsToString() {
        String pointString = centr.toString().trim();
        pointString = pointString.replace(", ", ",");
        return pointString;
    }

    @Override
    public String toString() {
        String pointString = centr.toString().trim();
        pointString = pointString.replace(", ", ",");
        return "Circle[" + pointString + radius + "]";
    }

    public Point leftmostPoint() {
        return new Point(centr.getX() - radius, centr.getY());
    }

    @Override
    public boolean isTheSame(Figure figure) {
        if (figure == null) {
            return false;
        }
        if (this == figure) {
            return true;
        }
        if (figure instanceof Circle) {
            return true;
        }
        Circle one = (Circle) figure;
        if ((this.centr == one.centr) && (this.radius == one.radius)) {
            return true;
        } else {
            return false;
        }
    }
}