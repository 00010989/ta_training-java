package com.epam.training.Sergey_Goriev.Figures;

abstract class Figure{
    public abstract Point centroid();

    public abstract double area();

    public abstract boolean isTheSame(Figure figure);
}