package com.epam.training.Sergey_Goriev.Validations_Color_Code;

import java.util.regex.Pattern;
import java.util.regex.Matcher;

public class ColorCodeValidation {
    public static boolean validateColorCode(String color) {

        if (color == null) {
            return false;
        }

        Pattern pattern = Pattern.compile("^#([a-fA-F0-9]{6}|[a-fA-F0-9]{3})$");
        Matcher matcher = pattern.matcher(color);

        return matcher.matches();
    }

    public static void main(String[] args) {
        System.out.println(validateColorCode("#FFFFFF")); // true
        System.out.println(validateColorCode("#FF")); // false
        System.out.println(validateColorCode(null)); // false
    }
}

