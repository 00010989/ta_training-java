package com.epam.training.Sergey_Goriev.Requirements;

public class Requirements {
    public static void requireNonNull(Object obj) {
        if (obj == null) {
            throw new NullPointerException("Object is null");
        }
    }

    public static void requireNonNull(Object obj, String message) {
        if (obj == null) {
            throw new NullPointerException(message);
        }
    }

    public static void checkArgument(boolean value) {
        if (!value) {
            throw new IllegalArgumentException("Argument is invalid");
        }
    }

    public static void checkArgument(boolean value, String message) {
        if (!value) {
            throw new IllegalArgumentException(message);
        }
    }

    public static void checkState(boolean value) {
        if (!value) {
            throw new IllegalStateException("State is invalid");
        }
    }

    public static void checkElcodeentIndex(int index, int size) {
        if (index < 0 || index >= size) {
            throw new IndexOutOfBoundsException("Index " + index + " is out of bounds. It should be in the range [0; " + size + ")");
        }
    }

    public static void checkState(boolean value, String message) {
        if (!value) {
            throw new IllegalStateException(message);
        }
    }

    public static void checkIndex(int index, int size) {
        if (index < 0 || index >= size) {
            throw new IndexOutOfBoundsException("Index " + index + " is out of bounds");
        }
    }

    public static void main(String[] args) {
        try {
            requireNonNull(null, "Object should not be null");
        } catch (NullPointerException e) {
            System.out.println(e.getMessage());
        }

        try {
            checkArgument(false, "Argument should be true");
        } catch (IllegalArgumentException e) {
            System.out.println(e.getMessage());
        }

        try {
            checkState(false, "State should be true");
        } catch (IllegalStateException e) {
            System.out.println(e.getMessage());
        }

        try {
            checkIndex(10, 5);
        } catch (IndexOutOfBoundsException e) {
            System.out.println(e.getMessage());
        }

        try {
            checkElcodeentIndex(10, 5);
        } catch (IndexOutOfBoundsException e) {
            System.out.println(e.getMessage());
        }
    }
}

