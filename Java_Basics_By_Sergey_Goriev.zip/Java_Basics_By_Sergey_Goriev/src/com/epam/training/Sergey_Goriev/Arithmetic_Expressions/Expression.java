package com.epam.training.Sergey_Goriev.Arithmetic_Expressions;

public interface Expression {
    int evaluate();
    String toExpressionString();
}
