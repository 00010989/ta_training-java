package com.epam.training.Sergey_Goriev.Meet_a_Stranger;

import java.util.Scanner;

public class MeetAStranger {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String ReadUserInput = scanner.nextLine();
        System.out.println("Hello, " + ReadUserInput);
    }
}
