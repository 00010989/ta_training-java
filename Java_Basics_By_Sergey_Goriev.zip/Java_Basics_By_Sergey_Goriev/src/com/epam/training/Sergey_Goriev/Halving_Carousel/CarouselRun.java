package com.epam.training.Sergey_Goriev.Halving_Carousel;

import java.util.Arrays;

public class CarouselRun {
    public static void main(String[] args) {
        CarouselRun run = new HalvingCarousel(7).run();
        System.out.println(run.isFinished()); //true
        System.out.println(run.next()); //-1
        System.out.println(" ");

        HalvingCarousel carousel = new HalvingCarousel(3);

        carousel.addElement(20);
        carousel.addElement(30);
        carousel.addElement(10);

        run = carousel.run();

        System.out.println(run.isFinished()); //false

        System.out.println(run.next()); //20
        System.out.println(run.next()); //30
        System.out.println(run.next()); //10

        System.out.println(run.next()); //10
        System.out.println(run.next()); //15
        System.out.println(run.next()); //5

        System.out.println(run.next()); //5
        System.out.println(run.next()); //7
        System.out.println(run.next()); //2

        System.out.println(run.next()); //2
        System.out.println(run.next()); //3
        System.out.println(run.next()); //1

        System.out.println(run.next()); //1
        System.out.println(run.next()); //1

        System.out.println(run.isFinished()); //true
        System.out.println(run.next()); //-1

        while (!run.isFinished()) {
            System.out.println(run.next());
        }
    }

    private final int[] container;
    private int i;
    private int sum = 0;
    private final int flagHalving;

    public CarouselRun (int[] container, int counter) {
        this.container = Arrays.copyOf(container, container.length);
        i = counter;
        flagHalving = 0;
        for (int elem : container ) {
            sum += elem;
        }
    }

    public CarouselRun (int[] container, int counter, int flag) {
        this.container = Arrays.copyOf(container, container.length);
        i = counter;
        flagHalving = flag;
        for (int elem : container ) {
            sum += elem;
        }
    }

    public int next() {
        int tempElem;
        if (isFinished()) {
            return -1;
        }
        if (i == container.length) {
            i = 0;
        }
        while (container[i] == 0) {
            i++;
            if (i == container.length) {
                i = 0;
            }
        }
        if (flagHalving == 0) {
            sum--;
            return container[i++]--;
        } else {
            tempElem = container[i];
            container[i] /= 2;
            sum = sum - container[i] - tempElem % 2;
            i++;
            return tempElem;
        }
    }

    public boolean isFinished() {
        return sum == 0;
    }
}

