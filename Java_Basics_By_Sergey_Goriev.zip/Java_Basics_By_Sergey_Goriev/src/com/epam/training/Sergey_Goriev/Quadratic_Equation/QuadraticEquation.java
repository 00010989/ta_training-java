package com.epam.training.Sergey_Goriev.Quadratic_Equation;

import java.text.DecimalFormat;
import java.util.Scanner;

public class QuadraticEquation {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        double a = input.nextDouble();
        double b = input.nextDouble();
        double c = input.nextDouble();
        double d= b * b - 4.0 * a * c;
        if (d > 0.0)
        {
            double r1 = (-b - Math.pow(d, 0.5)) / (2.0 * a);
            double r2 = (-b + Math.pow(d, 0.5)) / (2.0 * a);
            if (r1 == -3.0)
            {
                int valuer1 = (int)r1;
                System.out.println(valuer1  + " " + r2);
                return;
            }
            System.out.println(r1  + " " + r2);
        }
        else if (d == 0.0)
        {
            double r1 = -b / (2.0 * a);
            int valuer1 = (int)r1;
            System.out.println(valuer1);
        }
        else
        {
            System.out.println("no roots");
        }
    }
}
