package com.epam.training.Sergey_Goriev.Meet_an_Agent;

import java.util.Scanner;

public class MeetAnAgent {
    final static int PASSWORD = 133976;
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int UserInputNumber = scanner.nextInt();
        if (UserInputNumber == PASSWORD) {
            System.out.println("Hello, Agent");
        } else {
            System.out.println("Access denied");
        }
    }
}
