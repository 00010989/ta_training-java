package com.epam.training.Sergey_Goriev.Battleship8x8;

import java.util.List;

public class Battleship8x8 {
    public static void main(String[] args) {
        long map = 0b11110000_00000111_00000000_00110000_00000010_01000000_00000000_00000000L;
        List<String> shots = List.of("A1", "B2", "C3", "D4");
        Battleship8x8 game = new Battleship8x8(map);
        shots.forEach(game::shoot);
        System.out.println(game.state());
    }
    private final long ships;
    private long shots = 0L;

    public Battleship8x8(final long ships) {
        this.ships = ships;
    }

    public boolean shoot(String shot) {
        long newShot = 0b10000000_00000000_00000000_00000000_00000000_00000000_00000000_00000000L;
        switch (shot.charAt(0)) {
            case 'A': break;
            case 'B': {newShot >>>= 1; break;}
            case 'C': {newShot >>>= 2; break;}
            case 'D': {newShot >>>= 3; break;}
            case 'E': {newShot >>>= 4; break;}
            case 'F': {newShot >>>= 5; break;}
            case 'G': {newShot >>>= 6; break;}
            case 'H': {newShot >>>= 7; break;}
        }
        newShot >>>= (8 * (shot.charAt(1) - 1));
        shots |= newShot;
        if ((ships & newShot) != 0) {
            return true;
        }
        return false;
    }

    public String state() {
        String strShips = Long.toBinaryString(ships);
        String strShots = Long.toBinaryString(shots);
        StringBuilder bufZeros = new StringBuilder();
        if (strShots.length() < 64) {
            for (int i = 0; i < 64 - strShots.length(); i++)
                bufZeros.append("0");
            strShots = bufZeros.append(strShots).toString();
            bufZeros.delete(0, bufZeros.length());
        }
        if (strShips.length() < 64) {
            for (int i = 0; i < 64 - strShips.length(); i++)
                bufZeros.append("0");
            strShips = bufZeros.append(strShips).toString();
            bufZeros.delete(0, bufZeros.length());
        }
        StringBuilder result = new StringBuilder();
        for (int i = 0; i < strShots.length(); i++) {
            if (i%8 == 0)
                result.append("\n");
            if (strShips.charAt(i) == '0' && strShots.charAt(i) == '0')
                result.append(".");
            if (strShips.charAt(i) == '0' && strShots.charAt(i) == '1')
                result.append("×");
            if (strShips.charAt(i) == '1' && strShots.charAt(i) == '0')
                result.append("☐");
            if (strShips.charAt(i) == '1' && strShots.charAt(i) == '1')
                result.append("☒");
        }
        return result.toString();
    }
}
