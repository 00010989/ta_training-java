package com.epam.training.Sergey_Goriev.Contact_Book;

public interface ContactInfo {
    String getTitle();
    String getValue();
}