package com.epam.training.Sergey_Goriev.Beware_of_Dogs.residents.cats;

public class Kitten extends Cat {
    public Kitten(String name) { super(name); }
    @Override
    public String toString() { return "Kitten " + name; }
}
