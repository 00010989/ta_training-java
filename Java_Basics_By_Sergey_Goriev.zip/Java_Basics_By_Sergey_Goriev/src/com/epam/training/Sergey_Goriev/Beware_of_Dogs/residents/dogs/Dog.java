package com.epam.training.Sergey_Goriev.Beware_of_Dogs.residents.dogs;

public class Dog {
    String name;
    public Dog(String name) { this.name = name; }
    @Override
    public String toString() { return "Dog " + name; }
}
