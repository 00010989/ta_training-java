package com.epam.training.Sergey_Goriev.Max_method;

import java.util.Arrays;

public class MaxMethod {
    public static void main(String[] args) {
        int[] array = {-2, 0, 10, 5};
        System.out.println(max(array));
    }
    public static int max(int[] array) {
        if (array == null || array.length == 0) {
            throw new IllegalArgumentException("The array must not be null or empty");
        }
        int max = array[0];
        for (int i = 1; i < array.length; i++){
            if(array[i] > max){
                max = array[i];
            }
        }
        return max;
    }
}