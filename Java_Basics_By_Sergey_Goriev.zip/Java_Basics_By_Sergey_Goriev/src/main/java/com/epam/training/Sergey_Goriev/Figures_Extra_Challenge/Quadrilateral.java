package com.epam.training.Sergey_Goriev.Figures_Extra_Challenge;

class Quadrilateral extends Figure {
    Point a;
    Point b;
    Point c;
    Point d;
    private boolean isP4Inside;
    private Triangle abc;
    private Triangle adc;
    private Triangle bcd;
    private Triangle bad;

    public Quadrilateral(Point a, Point b, Point c, Point d) {

        Segment ab = new Segment(a, b);
        Segment bc = new Segment(b, c);
        Segment cd = new Segment(c, d);
        Segment da = new Segment(d, a);

        if (ab.intersection(cd) != null) throw new IllegalArgumentException();
        if (bc.intersection(da) != null) throw new IllegalArgumentException();

        abc = new Triangle(a, b, c);
        adc = new Triangle(a, d, c);
        bcd = new Triangle(b, c, d);
        bad = new Triangle(b, a, d);

        if (!isRelativelyEqual(abc.area() + adc.area(), bcd.area() + bad.area()))
            throw new IllegalArgumentException();

        this.a = a;
        this.b = b;
        this.c = c;
        this.d = d;
    }

    @Override
    public Point centroid() {
        Segment line1 = new Segment(abc.centroid(), adc.centroid());
        Segment line2 = new Segment(bcd.centroid(), bad.centroid());
        return line1.intersection(line2);
    }

    public static Point findIntersection(Point l1s, Point l1e, Point l2s, Point l2e) {

        double a1 = l1e.getY() - l1s.getY();
        double b1 = l1s.getX() - l1e.getX();
        double c1 = a1 * l1s.getX() + b1 * l1s.getY();

        double a2 = l2e.getY() - l2s.getY();
        double b2 = l2s.getX() - l2e.getX();
        double c2 = a2 * l2s.getX() + b2 * l2s.getY();

        double delta = a1 * b2 - a2 * b1;
        if (delta == 0) {
            return null;
        }
        return new Point((b2 * c1 - b1 * c2) / delta, (a1 * c2 - a2 * c1) / delta);
    }

    @Override
    public double area() {
        double area1 = Math.abs(a.x*(b.y-c.y) + b.x*(c.y-a.y) + c.x*(a.y-b.y))/2;
        double area2 = Math.abs(a.x*(c.y-d.y) + c.x*(d.y-a.y) + d.x*(a.y-c.y))/2;

        return area1 + area2;
    }

    public String pointsToString() {
        String aString = a.toString().trim();
        String bString = b.toString().trim();
        String cString = c.toString().trim();
        String dString = d.toString().trim();

        aString = aString.replace(", ", ",");
        bString = bString.replace(", ", ",");
        cString = cString.replace(", ", ",");
        dString = dString.replace(", ", ",");

        return aString + bString + cString + dString;
    }

    @Override
    public String toString() {
        String aString = a.toString().trim();
        String bString = b.toString().trim();
        String cString = c.toString().trim();
        String dString = d.toString().trim();

        aString = aString.replace(", ", ",");
        bString = bString.replace(", ", ",");
        cString = cString.replace(", ", ",");
        dString = dString.replace(", ", ",");

        return "Quadrilateral[" + aString + bString + cString + dString + "]";
    }

    public Point leftmostPoint() {
        if (a.getX() <= b.getX() && a.getX() <= c.getX() && a.getX() <= d.getX()) {
            return a;
        } else if (b.getX() <= a.getX() && b.getX() <= c.getX() && b.getX() <= d.getX()) {
            return b;
        } else if (c.getX() <= a.getX() && c.getX() <= b.getX() && c.getX() <= d.getX()) {
            return c;
        } else {
            return d;
        }
    }

    @Override
    public boolean isTheSame(Figure figure) {
        Quadrilateral quad = ((Quadrilateral) figure);
        Point[] points = new Point[4];
        points[0] = quad.a;
        points[1] = quad.b;
        points[2] = quad.c;
        points[3] = quad.d;

        for (Point point: points) {

            if (!a.isTheSame(point)
                    && !b.isTheSame(point)
                    && !c.isTheSame(point)
                    && !d.isTheSame(point))

                return false;
        }
        return true;
    }
}