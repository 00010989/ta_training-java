package com.epam.training.Sergey_Goriev.Figures_Extra_Challenge;

import java.util.Arrays;

class Triangle extends Figure {
    Point a;
    Point b;
    Point c;
    double length1, length2, length3;
    private final Segment ab;
    private final Segment bc;
    private final Segment ca;

    public Triangle(Point a, Point b, Point c) {

        ab = new Segment(a, b);
        bc = new Segment(b, c);
        ca = new Segment(c, a);

        double[] lengthArray = new double[]{
                Math.abs(ab.length() * 100),
                Math.abs(bc.length() * 100),
                Math.abs(ca.length() * 100)};
        Arrays.sort(lengthArray);

        if (isRelativelyEqual(lengthArray[0] + lengthArray[1], lengthArray[2]))
            throw new IllegalArgumentException();

        this.a = a;
        this.b = b;
        this.c = c;

    }

    double length1(Point a, Point b) {
        double xDistanceSquare = Math.pow(a.getX() - b.getX(), 2);
        double yDistanceSquare = Math.pow(a.getY() - b.getY(), 2);
        return Math.sqrt(xDistanceSquare + yDistanceSquare);
    }

    double length2(Point a, Point c) {
        double xDistanceSquare = Math.pow(a.getX() - c.getX(), 2);
        double yDistanceSquare = Math.pow(a.getY() - c.getY(), 2);
        return Math.sqrt(xDistanceSquare + yDistanceSquare);
    }

    double length3(Point c, Point b) {
        double xDistanceSquare = Math.pow(c.getX() - b.getX(), 2);
        double yDistanceSquare = Math.pow(c.getY() - b.getY(), 2);
        return Math.sqrt(xDistanceSquare + yDistanceSquare);
    }

    @Override
    public Point centroid() {
        double xc = (a.getX() + b.getX() + c.getX()) / 3;
        double yc = (a.getY() + b.getY() + c.getY()) / 3;
        return new Point(xc, yc);
    }

    public double area() {
        return Math.abs(a.x*(b.y-c.y) + b.x*(c.y-a.y) + c.x*(a.y-b.y))/2;
    }

    public String pointsToString() {
        String aString = a.toString().trim();
        String bString = b.toString().trim();
        String cString = c.toString().trim();

        aString = aString.replace(", ", ",");
        bString = bString.replace(", ", ",");
        cString = cString.replace(", ", ",");

        return aString + bString + cString;
    }


    @Override
    public String toString() {
        String aString = a.toString().trim();
        String bString = b.toString().trim();
        String cString = c.toString().trim();

        aString = aString.replace(", ", ",");
        bString = bString.replace(", ", ",");
        cString = cString.replace(", ", ",");

        return "Triangle[" + aString + bString + cString + "]";
    }

    public Point leftmostPoint() {
        if (a.getX() <= b.getX() && a.getX() <= c.getX()) {
            return a;
        } else if (b.getX() <= a.getX() && b.getX() <= c.getX()) {
            return b;
        } else {
            return c;
        }
    }

    @Override
    public boolean isTheSame(Figure figure) {
        if (this == figure) {
            return true;
        }
        if (figure instanceof Triangle) {
            return true;
        }
        if (figure == null) {
            return false;
        }
        Triangle one = (Triangle) figure;
        return (this.a == one.a) && (this.b == one.b) && (this.c == one.c);
    }
}