package com.epam.training.Sergey_Goriev.Arithmetic_Expressions;

import java.text.DecimalFormat;

public class Expressions {
    public static void main(String[] args) {
        Variable a = var("a", 5);
        Variable b = var("b", 22);
        Variable c = var("c", 98);

        Expression expr = fraction(
                product(a, sum(val(8), b)),
                difference(val(100), c)
        );

        System.out.println(expr.toExpressionString() + " = " + expr.evaluate());

        Expression val = val(789);
        System.out.println(val.evaluate());
        System.out.println(val.toExpressionString());

        val = val(-951);
        System.out.println(val.evaluate());
        System.out.println(val.toExpressionString());

        Expression sum;
        sum = sum(var("a", 7), val(9));
        System.out.println(sum.toExpressionString() + " = " + sum.evaluate());

        sum = sum(var("a", -7), val(-2), var("alpha", 789));
        System.out.println(sum.toExpressionString() + " = " + sum.evaluate());

        sum = sum(val(1), val(2), val(3), val(4), val(5), val(6));
        System.out.println(sum.toExpressionString() + " = " + sum.evaluate());

        Variable x1 = var("x1", 7);
        Variable x2 = var("x2", 7);
        Variable x3 = var("x3", 7);
        sum = sum(x1, x2, x3);

        System.out.println(sum.toExpressionString() + " = " + sum.evaluate());

        x1.setValue(159);
        x2.setValue(753);
        x3.setValue(-1000);

        System.out.println(sum.toExpressionString() + " = " + sum.evaluate());

        Expression prod;
        prod = product(var("a", 7), val(9));
        System.out.println(prod.toExpressionString() + " = " + prod.evaluate());

        prod = product(var("a", -7), val(-2), var("alpha", 789));
        System.out.println(prod.toExpressionString() + " = " + prod.evaluate());

        prod = product(val(1), val(2), val(3), val(4), val(5), val(6));
        System.out.println(prod.toExpressionString() + " = " + prod.evaluate());

        x1 = var("x1", 7);
        x2 = var("x2", 7);
        x3 = var("x3", 7);
        prod = product(x1, x2, x3);
        System.out.println(prod.toExpressionString() + " = " + prod.evaluate());

        x1.setValue(159);
        x2.setValue(753);
        x3.setValue(-1000);
        DecimalFormat df = new DecimalFormat("#,###");
        String formattedOutput = df.format(prod.evaluate()).replace('\u00A0', '_');
        System.out.println(prod.toExpressionString() + " = " + formattedOutput);

        Expression diff;
        diff = difference(var("a", 72), val(9));
        System.out.println(diff.toExpressionString() + " = " + diff.evaluate());

        diff = difference(var("a", -77), val(-11));
        System.out.println(diff.toExpressionString() + " = " + diff.evaluate());

        x1 = var("x1", 7);
        x2 = var("x2", 7);
        diff = difference(x1, x2);
        System.out.println(diff.toExpressionString() + " = " + diff.evaluate());

        x1.setValue(343);
        x2.setValue(-7);
        System.out.println(diff.toExpressionString() + " = " + diff.evaluate());

        Expression fraction;
        fraction = fraction(var("a", 72), val(9));
        System.out.println(fraction.toExpressionString() + " = " + fraction.evaluate());

        fraction = fraction(var("a", -77), val(-11));
        System.out.println(fraction.toExpressionString() + " = " + fraction.evaluate());

        x1 = var("x1", 7);
        x2 = var("x2", 7);
        fraction = fraction(x1, x2);
        System.out.println(fraction.toExpressionString() + " = " + fraction.evaluate());

        x1.setValue(343);
        x2.setValue(-7);
        System.out.println(fraction.toExpressionString() + " = " + fraction.evaluate());

        Expression expression = sum(val(1), sum(val(2), sum(val(3), sum(val(4), val(5)))));
        System.out.println(expression.toExpressionString() + " = " + expression.evaluate());

        expression = product(val(1), product(val(2), product(val(3), product(val(4), val(5)))));
        System.out.println(expression.toExpressionString() + " = " + expression.evaluate());

        expression = fraction(val(999_999), fraction(val(81), fraction(val(27), fraction(val(9), val(3)))));
        df = new DecimalFormat("#,###");
        formattedOutput = df.format(expression.evaluate()).replace('\u00A0', '_');
        System.out.println(expression.toExpressionString() + " = " + formattedOutput);

        expression = difference(val(999_999), difference(val(81), difference(val(27), difference(val(9), val(3)))));
        df = new DecimalFormat("#,###");
        formattedOutput = df.format(expression.evaluate()).replace('\u00A0', '_');
        System.out.println(expression.toExpressionString() + " = " + formattedOutput);
    }

    public static Variable var(String name, int value) {
        return new Variable(name, value);
    }

    public static Expression val(int value) {
        return new Expression() {
            @Override
            public int evaluate() {
                return value;
            }

            @Override
            public String toExpressionString() {
                if (value < 0) {
                    return "(" + value + ")";
                } else {
                    return String.valueOf(value);
                }
            }
        };
    }

    public static Expression sum(Expression... members) {
        return new Expression() {
            @Override
            public int evaluate() {
                int sum = 0;
                for (Expression member : members) {
                    sum += member.evaluate();
                }
                return sum;
            }

            @Override
            public String toExpressionString() {
                StringBuilder sb = new StringBuilder("(");
                for (Expression member : members) {
                    sb.append(member.toExpressionString()).append(" + ");
                }
                sb.delete(sb.length() - 3, sb.length());
                sb.append(")");
                return sb.toString();
            }
        };
    }

    public static Expression product(Expression... members) {
        return new Expression() {
            @Override
            public int evaluate() {
                int product = 1;
                for (Expression member : members) {
                    product *= member.evaluate();
                }
                return product;
            }

            @Override
            public String toExpressionString() {
                StringBuilder sb = new StringBuilder("(");
                for (Expression member : members) {
                    sb.append(member.toExpressionString()).append(" * ");
                }
                sb.delete(sb.length() - 3, sb.length());
                sb.append(")");
                return sb.toString();
            }
        };
    }

    public static Expression difference(Expression minuend, Expression subtrahend) {
        return new Expression() {
            @Override
            public int evaluate() {
                return minuend.evaluate() - subtrahend.evaluate();
            }

            @Override
            public String toExpressionString() {
                return "(" + minuend.toExpressionString() + " - " + subtrahend.toExpressionString() + ")";
            }
        };
    }

    public static Expression fraction(Expression dividend, Expression divisor) {
        return new Expression() {
            @Override
            public int evaluate() {
                return dividend.evaluate() / divisor.evaluate();
            }

            @Override
            public String toExpressionString() {
                return "(" + dividend.toExpressionString() + " / " + divisor.toExpressionString() + ")";
            }
        };
    }
}


