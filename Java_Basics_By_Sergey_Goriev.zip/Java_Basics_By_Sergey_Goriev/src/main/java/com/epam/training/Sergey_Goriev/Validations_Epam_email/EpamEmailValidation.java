package com.epam.training.Sergey_Goriev.Validations_Epam_email;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class EpamEmailValidation {
    public static boolean validateEpamEmail(String email) {
        if (email == null) {
            return false;
        }

        Pattern pattern = Pattern.compile("^[a-z]+_[a-z]+(\\d*)@epam\\.com$");
        Matcher matcher = pattern.matcher(email);

        return matcher.matches();
    }

    public static void main(String[] args) {
        // Incorrect examples
        System.out.println(validateEpamEmail("william@epam.com")); // false
        System.out.println(validateEpamEmail("william.shakespeare@epam.com")); // false
        System.out.println(validateEpamEmail("william...shakespeare@epam.com")); // false
        System.out.println(validateEpamEmail("william-shakespeare@epam.com")); // false
        System.out.println(validateEpamEmail("shakespeare123@epam.com")); // false
        System.out.println(validateEpamEmail("william_$hakespeare@epam.com")); // false
        System.out.println(" ");

        // Correct examples
        System.out.println(validateEpamEmail("william_shakespeare@epam.com")); // true
        System.out.println(validateEpamEmail("lu_e@epam.com")); // true
        System.out.println(validateEpamEmail("william_shakespeare1@epam.com")); // true
        System.out.println(validateEpamEmail("william_shakespeare2@epam.com")); // true
    }
}

