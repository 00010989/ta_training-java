package com.epam.training.Sergey_Goriev.Gradually_Decreasing_Carousel;

public class GraduallyDecreasingCarousel extends DecrementingCarousel{
    public GraduallyDecreasingCarousel(final int capacity) {
        super(capacity);
    }

    @Override
    public CarouselRun run() {
        if (!thisCarouselRunning()) {
            setCarouselRunning(true);
            return new CarouselRun(getCarousel(), 1);
        }
        return null;
    }
}

