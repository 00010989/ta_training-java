package com.epam.training.Sergey_Goriev.Gradually_Decreasing_Carousel;

public class CarouselRun {
    private int[] carousel;
    private int cursor;
    private int action;
    private int gradully = 1;

    public CarouselRun(int[] carousel, int action) {
        this.carousel = carousel;
        this.action = action;
    }

    public int next() {
        if (isFinished()) {
            return -1;
        }
        while (carousel[cursor] <= 0) {
            if (cursor >= carousel.length - 1) {
                gradully++;
                cursor = 0;
                continue;
            }
            cursor++;
        }
        int nextEl = carousel[cursor];
        switch (action) {
            case 0:
                carousel[cursor]--;
                break;
            case 1:
                carousel[cursor] = carousel[cursor] - gradully;
                break;
            default:
        }
        cursor++;
        if (cursor == carousel.length){
            cursor = 0;
            gradully++;
        }
        return nextEl;
    }

    public boolean isFinished() {
        for (int i = 0; i < carousel.length; i++) {
            if (carousel[i] > 0) {
                return false;
            }
        }
        return true;

    }

    public static void main(String[] args) {
        CarouselRun run = new GraduallyDecreasingCarousel(7).run();
        System.out.println(run.isFinished()); //true
        System.out.println(run.next()); //-1
        System.out.println(" ");

        DecrementingCarousel carousel = new GraduallyDecreasingCarousel(7);

        carousel.addElement(20);
        carousel.addElement(30);
        carousel.addElement(10);

        run = carousel.run();

        System.out.println(run.isFinished()); //false

        System.out.println(run.next()); //20
        System.out.println(run.next()); //30
        System.out.println(run.next()); //10

        System.out.println(run.next()); //19
        System.out.println(run.next()); //29
        System.out.println(run.next()); //9

        System.out.println(run.next()); //17
        System.out.println(run.next()); //27
        System.out.println(run.next()); //7

        System.out.println(run.next()); //14
        System.out.println(run.next()); //24
        System.out.println(run.next()); //4

        System.out.println(run.next()); //10
        System.out.println(run.next()); //20

        System.out.println(run.next()); //5
        System.out.println(run.next()); //15

        System.out.println(run.next()); //9

        System.out.println(run.next()); //2

        System.out.println(run.isFinished()); //true
        System.out.println(run.next()); //-1

        while (!run.isFinished()) {
            System.out.println(run.next());
        }
    }
}

