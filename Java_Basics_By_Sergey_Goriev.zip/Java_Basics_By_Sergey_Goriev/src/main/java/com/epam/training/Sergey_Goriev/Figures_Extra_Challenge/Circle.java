package com.epam.training.Sergey_Goriev.Figures_Extra_Challenge;

class Circle extends Figure {
    private Point center;
    double radius;

    public Circle(Point centr, double radius) throws IllegalArgumentException {
        if (centr != null) {
            this.center = centr;
            this.radius = radius;
        }
        if (radius <= 0 || centr == null) {
            throw new IllegalArgumentException();
        }
    }

    @Override
    public Point centroid() {
        return center;
    }

    @Override
    public double area() {
        return Math.PI * Math.pow(radius, 2);
    }

    public String pointsToString() {
        String pointString = center.toString().trim();
        pointString = pointString.replace(", ", ",");
        return pointString;
    }

    @Override
    public String toString() {
        String pointString = center.toString().trim();
        pointString = pointString.replace(", ", ",");
        return "Circle[" + pointString + radius + "]";
    }

    public Point leftmostPoint() {
        return new Point(center.getX() - radius, center.getY());
    }

    @Override
    public boolean isTheSame(Figure figure) {
        if (figure.getClass() != getClass()) return false;
        return center.isTheSame(((Circle) figure).center) && isRelativelyEqual(radius , ((Circle) figure).radius);
    }
}