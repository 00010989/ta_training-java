package com.epam.training.Sergey_Goriev.Local_maxima_remove;

import java.util.Arrays;

public class LocalMaximaRemove {
    public static void main(String[] args) {
        int[] array = new int[]{18, 1, 3, 6, 7, -5};
        array = Arrays.copyOf(array, array.length + 1);
        for (int i : array) {
            System.out.println(Arrays.toString(removeLocalMaxima(array)));
            break;
        }
    }

    public static int[] removeLocalMaxima(int[] a)
    {
        for (int i=0; i<a.length; i++)
            if((i==0 || a[i-1]<a[i]) && (i==a.length-1 || a[i+1]<a[i]))
            {
                int[] b = new int[a.length-1];
                System.arraycopy(a,0,b,0,i);
                if(i<a.length-1)
                    System.arraycopy(a,i+1,b,i,a.length-i-1);
                a=b.clone();
            }
        return a;
    }
}
