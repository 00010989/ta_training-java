package com.epam.training.Sergey_Goriev.Beware_of_Dogs.residents.cats;

public class Cat {
    String name;
    public Cat(String name) { this.name = name; }
    @Override
    public String toString() { return "Cat " + name; }
}

