package com.epam.training.Sergey_Goriev.Go_Dutch;

import java.util.Scanner;

public class GoDutch {
    public static void main(String[] args) {
        Scanner scanner = new Scanner( System.in );
        int BillValue = scanner.nextInt();

        if (BillValue < 0) {
            System.out.println("Bill total amount cannot be negative");
            return;
        }

        int AmountFriends = scanner.nextInt();

        if (AmountFriends <= 0) {
            System.out.println("Number of friends cannot be negative or zero");
            return;
        } else if (AmountFriends > 100){
            System.out.println("1");
            return;
        }

        int PartPayment = BillValue/AmountFriends;

        System.out.println(PartPayment + PartPayment / 10);
    }
}
