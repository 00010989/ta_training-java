package com.epam.training.Sergey_Goriev.Line_Intersection;

public class Line {

    int b2;
    int b1;
    int k1;
    int k2;

    public Line(int k, int b) {
        this.k1 = k;
        this.k2 = k;
        this.b1 = b;
        this.b2 = b;
    }

    public Point intersection(Line other) {
        int x, y;
        if (this.k1 == other.k2) {
            System.out.println("Lines are parallel and do not intersect");
            return null;
        } else {
            x = (other.b2 - this.b1) / (this.k1 - other.k2);
            y = this.k1 * x + this.b1;
        }
        return new Point(x, y);
    }
}

