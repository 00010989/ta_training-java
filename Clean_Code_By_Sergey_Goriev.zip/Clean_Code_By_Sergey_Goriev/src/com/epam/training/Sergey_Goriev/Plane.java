package com.epam.training.Sergey_Goriev;

import java.util.Objects;

public abstract class Plane {
    String planeModel;
    private final int maxSpeed;
    private final int maxFlightDistance;
    private final int maxLoadCapacity;

    protected Plane(String planeModel, int maxSpeed, int maxFlightDistance, int maxLoadCapacity) {
        this.planeModel = planeModel;
        this.maxSpeed = maxSpeed;
        this.maxFlightDistance = maxFlightDistance;
        this.maxLoadCapacity = maxLoadCapacity;
    }

    public String getPlaneModel() {
        return planeModel;
    }

    public int getMaxSpeed() {
        return maxSpeed;
    }

    public int getMaxFlightDistance() {
        return maxFlightDistance;
    }

    public int getMinLoadCapacity() {
        return this.maxLoadCapacity;
    }

    @Override
    public boolean equals(Object plane) {
        if (this == plane) return true;
        if (!(plane instanceof Plane planeInstance)) return false;
        return maxSpeed == planeInstance.maxSpeed &&
                maxFlightDistance == planeInstance.maxFlightDistance &&
                maxLoadCapacity == planeInstance.maxLoadCapacity &&
                Objects.equals(planeModel, planeInstance.planeModel);
    }

    @Override
    public int hashCode() {
        return Objects.hash(planeModel, maxSpeed, maxFlightDistance, maxLoadCapacity);
    }

    @Override
    public String toString() {
        return "Plane{" +
                "model of this plane='" + planeModel + '\'' +
                ", maxSpeed=" + maxSpeed +
                ", maxFlightDistance=" + maxFlightDistance +
                ", maxLoadCapacity=" + maxLoadCapacity +
                '}';
    }
}
