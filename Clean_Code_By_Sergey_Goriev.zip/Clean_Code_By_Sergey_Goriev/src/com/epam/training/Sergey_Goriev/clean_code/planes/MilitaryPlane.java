package com.epam.training.Sergey_Goriev.clean_code.planes;

import com.epam.training.Sergey_Goriev.Plane;
import com.epam.training.Sergey_Goriev.clean_code.models.MilitaryType;

import java.util.Objects;

public class MilitaryPlane extends Plane {

    private final MilitaryType militaryType;

    public MilitaryPlane(String militaryPlaneModel, int maxSpeed, int maxFlightDistance, int maxLoadCapacity, MilitaryType militaryType) {
        super(militaryPlaneModel, maxSpeed, maxFlightDistance, maxLoadCapacity);
        this.militaryType = militaryType;
    }

    public MilitaryType getType() {
        return militaryType;
    }

    @Override
    public boolean equals(Object millitaryPlane) {
        if (this == millitaryPlane) return true;
        if (!(millitaryPlane instanceof MilitaryPlane militaryPlane)) return false;
        if (!super.equals(millitaryPlane)) return false;
        return militaryType == militaryPlane.militaryType;
    }

    @Override
    public int hashCode() {
        return Objects.hash(super.hashCode(), militaryType);
    }

    @Override
    public String toString() {
        return super.toString().replace("}",
                ", militaryType=" + militaryType +
                        '}');
    }
}

