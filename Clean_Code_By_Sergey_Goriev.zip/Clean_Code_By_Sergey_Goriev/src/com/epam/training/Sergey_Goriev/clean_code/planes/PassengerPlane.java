package com.epam.training.Sergey_Goriev.clean_code.planes;

import com.epam.training.Sergey_Goriev.Plane;
import java.util.Objects;

public class PassengerPlane extends Plane {

    private final int passengersCapacity;

    public PassengerPlane(String passengerPlaneModel, int maxSpeed, int maxFlightDistance, int maxLoadCapacity, int passengersCapacity) {
        super(passengerPlaneModel, maxSpeed, maxFlightDistance, maxLoadCapacity);
        this.passengersCapacity = passengersCapacity;
    }

    public int getPassengersCapacity() {
        return passengersCapacity;
    }

    @Override
    public boolean equals(Object passengerPlane) {
        if (this == passengerPlane) return true;
        if (!(passengerPlane instanceof PassengerPlane otherPassengerPlane)) return false;
        if (!super.equals(otherPassengerPlane)) return false;
        return passengersCapacity == otherPassengerPlane.passengersCapacity;
    }

    @Override
    public int hashCode() {
        return Objects.hash(super.hashCode(), passengersCapacity);
    }

    @Override
    public String toString() {
        return super.toString().replace("}",
                ", passengersCapacity=" + passengersCapacity +
                        '}');
    }
}

