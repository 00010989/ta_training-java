package com.epam.training.Sergey_Goriev.clean_code.models;

public enum ExperimentalType {
    LIFTING_BODY, HYPERSONIC, HIGH_ALTITUDE, VTOL
}
